package com.symbiotevoice;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Speech-to-text and text-to-speech using the voice features built into Windows,
 * so nothing extra has to be installed. Windows only. Quality is lower than Whisper/Piper.
 * The text is passed through a temp file, never on the command line.
 */
final class WindowsSpeech {

    private static final String STT_SCRIPT = String.join("\r\n",
            "param([string]$Wav)",
            "$ErrorActionPreference = 'Stop'",
            "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8",
            "Add-Type -AssemblyName System.Speech",
            "$rec = New-Object System.Speech.Recognition.SpeechRecognitionEngine",
            "try {",
            "  $rec.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))",
            "  $rec.SetInputToWaveFile($Wav)",
            "  $parts = @()",
            "  while ($true) {",
            "    $r = $rec.Recognize()",
            "    if ($null -eq $r) { break }",
            "    $parts += $r.Text",
            "  }",
            "  Write-Output (($parts -join ' ').Trim())",
            "} finally { $rec.Dispose() }",
            "");

    private static final String TTS_SCRIPT = String.join("\r\n",
            "param([string]$TextFile, [string]$OutWav, [string]$Voice)",
            "$ErrorActionPreference = 'Stop'",
            "Add-Type -AssemblyName System.Speech",
            "$text = [System.IO.File]::ReadAllText($TextFile, [System.Text.Encoding]::UTF8)",
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer",
            "try {",
            "  if ($Voice -and $Voice -ne 'default') { try { $s.SelectVoice($Voice) } catch { } }",
            "  $s.Rate = -1",
            "  $s.SetOutputToWaveFile($OutWav)",
            "  $s.Speak($text)",
            "} finally { $s.Dispose() }",
            "");

    /** wav: 16 kHz mono 16-bit. */
    static String transcribe(byte[] wav) throws Exception {
        requireWindows();
        Path dir = Files.createTempDirectory("symvoice");
        try {
            Path wavFile = dir.resolve("in.wav");
            Files.write(wavFile, wav);
            Path script = dir.resolve("stt.ps1");
            Files.writeString(script, STT_SCRIPT, StandardCharsets.US_ASCII);
            return run(script, 40, wavFile.toString()).trim();
        } finally {
            cleanup(dir);
        }
    }

    static AiClient.Audio speak(String text) throws Exception {
        requireWindows();
        Path dir = Files.createTempDirectory("symvoice");
        try {
            Path textFile = dir.resolve("text.txt");
            Files.writeString(textFile, text, StandardCharsets.UTF_8);
            Path out = dir.resolve("out.wav");
            Path script = dir.resolve("tts.ps1");
            Files.writeString(script, TTS_SCRIPT, StandardCharsets.US_ASCII);
            String voice = VoiceConfig.WINDOWS_VOICE.get().trim();
            run(script, 40, textFile.toString(), out.toString(), voice.isEmpty() ? "default" : voice);
            return AiClient.parseWav(Files.readAllBytes(out));
        } finally {
            cleanup(dir);
        }
    }

    private static String run(Path script, int timeoutSeconds, String... args) throws Exception {
        List<String> cmd = new ArrayList<>(List.of("powershell.exe", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-File", script.toString()));
        cmd.addAll(List.of(args));
        Process p = new ProcessBuilder(cmd).start();
        p.getOutputStream().close();
        if (!p.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
            p.destroyForcibly();
            throw new IllegalStateException("Windows speech took too long");
        }
        String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        if (p.exitValue() != 0) {
            String err = new String(p.getErrorStream().readAllBytes(), StandardCharsets.UTF_8).trim();
            if (err.length() > 300) err = err.substring(0, 300);
            throw new IllegalStateException("Windows speech failed: " + err);
        }
        return out;
    }

    private static void requireWindows() {
        if (!System.getProperty("os.name", "").toLowerCase().contains("win")) {
            throw new IllegalStateException("The 'windows' speech engine only works on Windows. "
                    + "Set sttApi=whisper and ttsApi=piper (or openai) in the config.");
        }
    }

    private static void cleanup(Path dir) {
        try (var files = Files.list(dir)) {
            files.forEach(f -> f.toFile().delete());
        } catch (Exception ignored) {}
        dir.toFile().delete();
    }

    private WindowsSpeech() {}
}
