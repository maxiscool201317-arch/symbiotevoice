package com.symbiotevoice;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Settings screen: Mods list > Symbiote Voice > Config. Client side. */
public class SymbioteSettingsScreen extends Screen {
    private static final List<String> PROVIDERS = List.of("ollama", "grok", "anthropic");

    private final Screen parent;
    private String provider;
    private boolean chatter;
    private boolean hideLines;
    private final Map<String, String> keys = new HashMap<>();
    private final Map<String, String> models = new HashMap<>();
    private EditBox keyBox;
    private EditBox modelBox;

    public SymbioteSettingsScreen(Screen parent) {
        super(Component.literal("Symbiote Voice settings"));
        this.parent = parent;
        String p = VoiceConfig.provider();
        this.provider = PROVIDERS.contains(p) ? p : "ollama";
        keys.put("grok", VoiceConfig.GROK_KEY.get());
        keys.put("anthropic", VoiceConfig.ANTHROPIC_KEY.get());
        models.put("ollama", VoiceConfig.OLLAMA_MODEL.get());
        models.put("grok", VoiceConfig.GROK_MODEL.get());
        models.put("anthropic", VoiceConfig.ANTHROPIC_MODEL.get());
        this.chatter = VoiceConfig.CHATTER_ENABLED.get();
        this.hideLines = VoiceConfig.HIDE_WRITTEN_LINES.get();
    }

    @Override
    protected void init() {
        int w = 260;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 100;

        addRenderableWidget(Button.builder(Component.literal("AI brain: " + label(provider)), b -> {
            commitBoxes();
            provider = PROVIDERS.get((PROVIDERS.indexOf(provider) + 1) % PROVIDERS.size());
            rebuildWidgets();
        }).bounds(x, y, w, 20).build());

        y += 38;
        keyBox = new EditBox(this.font, x, y, w, 20, Component.literal("API key"));
        keyBox.setMaxLength(300);
        keyBox.setValue(keys.getOrDefault(provider, ""));
        keyBox.setFormatter((text, offset) -> FormattedCharSequence.forward("*".repeat(text.length()), Style.EMPTY));
        keyBox.setEditable(!provider.equals("ollama"));
        addRenderableWidget(keyBox);

        y += 38;
        modelBox = new EditBox(this.font, x, y, w, 20, Component.literal("Model name"));
        modelBox.setMaxLength(100);
        modelBox.setValue(models.getOrDefault(provider, ""));
        addRenderableWidget(modelBox);

        y += 28;
        addRenderableWidget(Button.builder(toggleText("Random chatter", chatter), b -> {
            chatter = !chatter;
            b.setMessage(toggleText("Random chatter", chatter));
        }).bounds(x, y, w, 20).build());

        y += 24;
        addRenderableWidget(Button.builder(toggleText("Hide the mod's written lines", hideLines), b -> {
            hideLines = !hideLines;
            b.setMessage(toggleText("Hide the mod's written lines", hideLines));
        }).bounds(x, y, w, 20).build());

        y += 34;
        addRenderableWidget(Button.builder(Component.literal("Save"), b -> {
            save();
            onClose();
        }).bounds(x, y, w / 2 - 2, 20).build());
        addRenderableWidget(Button.builder(CommonComponents.GUI_CANCEL, b -> onClose())
                .bounds(x + w / 2 + 2, y, w / 2 - 2, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 20, 0xFFFFFF);
        int x = this.width / 2 - 130;
        g.drawString(this.font,
                provider.equals("ollama") ? "API key (not needed for Ollama)" : "API key (hidden as you type)",
                x, keyBox.getY() - 11, 0xA0A0A0);
        g.drawString(this.font, "Model name", x, modelBox.getY() - 11, 0xA0A0A0);
        g.drawCenteredString(this.font, "Whisper and Piper addresses live in config/symbiotevoice-common.toml",
                this.width / 2, this.height - 24, 0x808080);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public void onClose() {
        this.minecraft.setScreen(parent);
    }

    private void commitBoxes() {
        if (keyBox != null && !provider.equals("ollama")) keys.put(provider, keyBox.getValue().trim());
        if (modelBox != null) models.put(provider, modelBox.getValue().trim());
    }

    private void save() {
        commitBoxes();
        VoiceConfig.CHAT_PROVIDER.set(provider);
        VoiceConfig.GROK_KEY.set(keys.getOrDefault("grok", "").trim());
        VoiceConfig.ANTHROPIC_KEY.set(keys.getOrDefault("anthropic", "").trim());
        setIfNotBlank(VoiceConfig.OLLAMA_MODEL, models.get("ollama"));
        setIfNotBlank(VoiceConfig.GROK_MODEL, models.get("grok"));
        setIfNotBlank(VoiceConfig.ANTHROPIC_MODEL, models.get("anthropic"));
        VoiceConfig.CHATTER_ENABLED.set(chatter);
        VoiceConfig.HIDE_WRITTEN_LINES.set(hideLines);
        VoiceConfig.SPEC.save();
    }

    private static void setIfNotBlank(net.minecraftforge.common.ForgeConfigSpec.ConfigValue<String> value, String text) {
        if (text != null && !text.isBlank()) value.set(text.trim());
    }

    private static String label(String p) {
        return switch (p) {
            case "grok" -> "Grok (xAI)";
            case "anthropic" -> "Claude (Anthropic)";
            default -> "Ollama (free, on this PC)";
        };
    }

    private static Component toggleText(String name, boolean on) {
        return Component.literal(name + ": " + (on ? "ON" : "OFF"));
    }
}
